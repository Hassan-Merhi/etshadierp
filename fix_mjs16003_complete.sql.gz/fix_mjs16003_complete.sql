-- ================================================================
-- COMPLETE FIX: Restore MJS16003 after merge into MJS6171 on Render
-- Source: Render backup 2026-05-26T07:57Z (pre-merge state confirmed)
--
-- MJS16003 (MJS LADY SUMMER DRESS LONG CRÈME 40 KGS)   = stock_item_id 760
-- MJS6171  (MJS LADY SUMMER DRESS LONG + CREME 40 KGS) = stock_item_id 759
--
-- WHAT THIS FIXES:
--   1. stock_items       — reactivate MJS16003 (strip [MERGED], active=true)
--   2. stock_item_code_aliases — remove alias MJS16003→MJS6171 created by merge
--   3. inventory         — restore 77 BL across 17 locations
--
-- WHAT IS ALREADY CORRECT (no fix needed):
--   sales_items          — MJS16003 has 2 sales (correct), MJS6171 has 32 (correct)
--   po_line_items        — unchanged by merge, both items correctly referenced
--   container_offload_items — OTW records correctly split between 759 & 760
--   stock_transfer_items — 3 transfers for MJS16003 (760) are correct
--   stock_adjustment_items — fine
--   stock_item_location_prices — neither item had custom prices
--
-- HOW TO RUN ON RENDER:
--   psql "postgres://USER:PASS@HOST/DB"
--   Paste this file (or: \i fix_mjs16003_complete.sql)
--   Review the SELECT output shown at the end
--   COMMIT  if everything looks right
--   ROLLBACK  if anything looks wrong
-- ================================================================

BEGIN;

-- ──────────────────────────────────────────────────────────────────
-- STEP 1: Verify current state of both items
-- ──────────────────────────────────────────────────────────────────
SELECT id, code, name, active, deleted_at
FROM stock_items
WHERE id IN (759, 760) AND company_id = 1;

-- ──────────────────────────────────────────────────────────────────
-- STEP 2: Reactivate MJS16003 (undo the soft-delete the merge created)
-- ──────────────────────────────────────────────────────────────────
UPDATE stock_items
SET
    active     = true,
    deleted_at = NULL,
    name       = regexp_replace(name, '^\[MERGED\]\s*', '')
WHERE id = 760
  AND company_id = 1;

-- Verify
SELECT id, code, name, active, deleted_at FROM stock_items WHERE id = 760;

-- ──────────────────────────────────────────────────────────────────
-- STEP 3: Remove the alias MJS16003 → MJS6171 that the merge created
-- (This alias made MJS16003 scans resolve to MJS6171 — must be removed)
-- ──────────────────────────────────────────────────────────────────
DELETE FROM stock_item_code_aliases
WHERE alias_code  = 'MJS16003'
  AND stock_item_id = 759
  AND company_id    = 1;

-- Confirm alias is gone
SELECT * FROM stock_item_code_aliases
WHERE alias_code = 'MJS16003' OR stock_item_id IN (759, 760);

-- ──────────────────────────────────────────────────────────────────
-- STEP 4: Fix inventory
--
-- CASE 1 (9 locations): Only MJS16003 had stock here.
-- Merge remapped rows from stock_item_id 760 → 759. Remap back.
-- Locations: 21, 42, 46, 47, 50, 60, 69, 87, 127  (18 BL total)
-- ──────────────────────────────────────────────────────────────────
UPDATE inventory
SET stock_item_id = 760,
    last_updated  = NOW()
WHERE company_id    = 1
  AND stock_item_id = 759
  AND location_id   IN (21, 42, 46, 47, 50, 60, 69, 87, 127);

-- ──────────────────────────────────────────────────────────────────
-- CASE 2 (8 locations): Both items had stock.
-- Merge deleted MJS16003 rows and added quantities to MJS6171.
-- Fix: INSERT MJS16003 rows back, subtract from MJS6171.
-- (59 BL / $20,791.29 value)
-- ──────────────────────────────────────────────────────────────────

-- loc 5 — MJS16003: 2 BL @ 332.25
INSERT INTO inventory (company_id, location_id, stock_item_id, quantity, average_rate, total_value, last_updated)
VALUES (1, 5, 760, 2.000, 332.25, 664.49, NOW());
UPDATE inventory SET
    quantity     = quantity     - 2.000,
    total_value  = total_value  - 664.49,
    average_rate = CASE WHEN (quantity - 2.000) > 0 THEN (total_value - 664.49) / (quantity - 2.000) ELSE average_rate END,
    last_updated = NOW()
WHERE company_id = 1 AND stock_item_id = 759 AND location_id = 5;

-- loc 76 — MJS16003: 2 BL @ 328.72
INSERT INTO inventory (company_id, location_id, stock_item_id, quantity, average_rate, total_value, last_updated)
VALUES (1, 76, 760, 2.000, 328.72, 657.43, NOW());
UPDATE inventory SET
    quantity     = quantity     - 2.000,
    total_value  = total_value  - 657.43,
    average_rate = CASE WHEN (quantity - 2.000) > 0 THEN (total_value - 657.43) / (quantity - 2.000) ELSE average_rate END,
    last_updated = NOW()
WHERE company_id = 1 AND stock_item_id = 759 AND location_id = 76;

-- loc 85 — MJS16003: 2 BL @ 331.96
INSERT INTO inventory (company_id, location_id, stock_item_id, quantity, average_rate, total_value, last_updated)
VALUES (1, 85, 760, 2.000, 331.96, 663.92, NOW());
UPDATE inventory SET
    quantity     = quantity     - 2.000,
    total_value  = total_value  - 663.92,
    average_rate = CASE WHEN (quantity - 2.000) > 0 THEN (total_value - 663.92) / (quantity - 2.000) ELSE average_rate END,
    last_updated = NOW()
WHERE company_id = 1 AND stock_item_id = 759 AND location_id = 85;

-- loc 100 — MJS16003: 3 BL @ 332.10
INSERT INTO inventory (company_id, location_id, stock_item_id, quantity, average_rate, total_value, last_updated)
VALUES (1, 100, 760, 3.000, 332.10, 996.30, NOW());
UPDATE inventory SET
    quantity     = quantity     - 3.000,
    total_value  = total_value  - 996.30,
    average_rate = CASE WHEN (quantity - 3.000) > 0 THEN (total_value - 996.30) / (quantity - 3.000) ELSE average_rate END,
    last_updated = NOW()
WHERE company_id = 1 AND stock_item_id = 759 AND location_id = 100;

-- loc 112 — MJS16003: 8 BL @ 332.85
INSERT INTO inventory (company_id, location_id, stock_item_id, quantity, average_rate, total_value, last_updated)
VALUES (1, 112, 760, 8.000, 332.85, 2662.83, NOW());
UPDATE inventory SET
    quantity     = quantity     - 8.000,
    total_value  = total_value  - 2662.83,
    average_rate = CASE WHEN (quantity - 8.000) > 0 THEN (total_value - 2662.83) / (quantity - 8.000) ELSE average_rate END,
    last_updated = NOW()
WHERE company_id = 1 AND stock_item_id = 759 AND location_id = 112;

-- loc 124 — MJS16003: 8 BL @ 332.77
INSERT INTO inventory (company_id, location_id, stock_item_id, quantity, average_rate, total_value, last_updated)
VALUES (1, 124, 760, 8.000, 332.77, 2662.19, NOW());
UPDATE inventory SET
    quantity     = quantity     - 8.000,
    total_value  = total_value  - 2662.19,
    average_rate = CASE WHEN (quantity - 8.000) > 0 THEN (total_value - 2662.19) / (quantity - 8.000) ELSE average_rate END,
    last_updated = NOW()
WHERE company_id = 1 AND stock_item_id = 759 AND location_id = 124;

-- loc 135 — MJS16003: 24 BL @ 347.41
INSERT INTO inventory (company_id, location_id, stock_item_id, quantity, average_rate, total_value, last_updated)
VALUES (1, 135, 760, 24.000, 347.41, 8337.84, NOW());
UPDATE inventory SET
    quantity     = quantity     - 24.000,
    total_value  = total_value  - 8337.84,
    average_rate = CASE WHEN (quantity - 24.000) > 0 THEN (total_value - 8337.84) / (quantity - 24.000) ELSE average_rate END,
    last_updated = NOW()
WHERE company_id = 1 AND stock_item_id = 759 AND location_id = 135;

-- loc 139 — MJS16003: 10 BL @ 346.91
INSERT INTO inventory (company_id, location_id, stock_item_id, quantity, average_rate, total_value, last_updated)
VALUES (1, 139, 760, 10.000, 346.91, 3469.12, NOW());
UPDATE inventory SET
    quantity     = quantity     - 10.000,
    total_value  = total_value  - 3469.12,
    average_rate = CASE WHEN (quantity - 10.000) > 0 THEN (total_value - 3469.12) / (quantity - 10.000) ELSE average_rate END,
    last_updated = NOW()
WHERE company_id = 1 AND stock_item_id = 759 AND location_id = 139;

-- ──────────────────────────────────────────────────────────────────
-- STEP 5: Verify final state — review before committing
-- ──────────────────────────────────────────────────────────────────

-- Inventory by location for both items
SELECT si.code, l.name AS location, i.location_id,
       i.quantity, i.average_rate, i.total_value
FROM inventory i
JOIN stock_items si ON si.id = i.stock_item_id
LEFT JOIN locations l ON l.id = i.location_id
WHERE i.stock_item_id IN (759, 760) AND i.company_id = 1
ORDER BY si.code, i.location_id;

-- Totals
SELECT si.code, COUNT(*) AS locations,
       SUM(i.quantity) AS total_qty,
       ROUND(SUM(i.total_value)::numeric, 2) AS total_value
FROM inventory i
JOIN stock_items si ON si.id = i.stock_item_id
WHERE i.stock_item_id IN (759, 760) AND i.company_id = 1
GROUP BY si.code;

-- Sales records (no changes needed — shown for reference)
SELECT si.code, COUNT(*) AS sale_lines, SUM(s.quantity) AS qty_sold
FROM sales_items s
JOIN stock_items si ON si.id = s.stock_item_id
WHERE s.stock_item_id IN (759, 760)
GROUP BY si.code;

-- ================================================================
-- Review the output above carefully, then:
--   COMMIT;    ← if everything looks correct
--   ROLLBACK;  ← if anything looks wrong
-- ================================================================
