-- ================================================================
-- RESTORE MJS16003 (MJS LADY SUMMER DRESS LONG CRÈME 40 KGS)
-- Run in TablePlus: paste into Query tab → Run All → review results
-- stock_item_id 760 = MJS16003    stock_item_id 759 = MJS6171
-- ================================================================

BEGIN;

-- ── BEFORE: see current state ──────────────────────────────────
SELECT id, code, name, active, deleted_at
FROM stock_items
WHERE id IN (759, 760) AND company_id = 1;

-- ── FIX 1: Reactivate MJS16003 ─────────────────────────────────
-- The merge soft-deleted it, prefixed name with [MERGED], set active=false
UPDATE stock_items
SET active     = true,
    deleted_at = NULL,
    name       = regexp_replace(name, '^\[MERGED\]\s*', '')
WHERE id = 760 AND company_id = 1;

-- ── FIX 2: Remove the alias MJS16003 → MJS6171 ─────────────────
-- The merge created this alias so MJS16003 scans resolved to MJS6171
DELETE FROM stock_item_code_aliases
WHERE alias_code    = 'MJS16003'
  AND stock_item_id = 759
  AND company_id    = 1;

-- ── FIX 3a: Inventory — 9 locations where ONLY MJS16003 had stock
-- Merge remapped these rows from item 760 → 759. Remap back.
-- Locations: 21, 42, 46, 47, 50, 60, 69, 87, 127  (18 BL)
UPDATE inventory
SET stock_item_id = 760,
    last_updated  = NOW()
WHERE company_id    = 1
  AND stock_item_id = 759
  AND location_id   IN (21, 42, 46, 47, 50, 60, 69, 87, 127);

-- ── FIX 3b: Inventory — 8 locations where BOTH items had stock
-- Merge deleted MJS16003 rows and combined into MJS6171.
-- Re-insert MJS16003 rows and subtract from MJS6171.  (59 BL)

-- loc 5: 2 BL @ 332.25
INSERT INTO inventory (company_id, location_id, stock_item_id, quantity, average_rate, total_value, last_updated)
VALUES (1, 5, 760, 2.000, 332.25, 664.49, NOW());
UPDATE inventory SET quantity=quantity-2.000, total_value=total_value-664.49,
    average_rate=CASE WHEN quantity-2.000>0 THEN (total_value-664.49)/(quantity-2.000) ELSE average_rate END,
    last_updated=NOW()
WHERE company_id=1 AND stock_item_id=759 AND location_id=5;

-- loc 76: 2 BL @ 328.72
INSERT INTO inventory (company_id, location_id, stock_item_id, quantity, average_rate, total_value, last_updated)
VALUES (1, 76, 760, 2.000, 328.72, 657.43, NOW());
UPDATE inventory SET quantity=quantity-2.000, total_value=total_value-657.43,
    average_rate=CASE WHEN quantity-2.000>0 THEN (total_value-657.43)/(quantity-2.000) ELSE average_rate END,
    last_updated=NOW()
WHERE company_id=1 AND stock_item_id=759 AND location_id=76;

-- loc 85: 2 BL @ 331.96
INSERT INTO inventory (company_id, location_id, stock_item_id, quantity, average_rate, total_value, last_updated)
VALUES (1, 85, 760, 2.000, 331.96, 663.92, NOW());
UPDATE inventory SET quantity=quantity-2.000, total_value=total_value-663.92,
    average_rate=CASE WHEN quantity-2.000>0 THEN (total_value-663.92)/(quantity-2.000) ELSE average_rate END,
    last_updated=NOW()
WHERE company_id=1 AND stock_item_id=759 AND location_id=85;

-- loc 100: 3 BL @ 332.10
INSERT INTO inventory (company_id, location_id, stock_item_id, quantity, average_rate, total_value, last_updated)
VALUES (1, 100, 760, 3.000, 332.10, 996.30, NOW());
UPDATE inventory SET quantity=quantity-3.000, total_value=total_value-996.30,
    average_rate=CASE WHEN quantity-3.000>0 THEN (total_value-996.30)/(quantity-3.000) ELSE average_rate END,
    last_updated=NOW()
WHERE company_id=1 AND stock_item_id=759 AND location_id=100;

-- loc 112: 8 BL @ 332.85
INSERT INTO inventory (company_id, location_id, stock_item_id, quantity, average_rate, total_value, last_updated)
VALUES (1, 112, 760, 8.000, 332.85, 2662.83, NOW());
UPDATE inventory SET quantity=quantity-8.000, total_value=total_value-2662.83,
    average_rate=CASE WHEN quantity-8.000>0 THEN (total_value-2662.83)/(quantity-8.000) ELSE average_rate END,
    last_updated=NOW()
WHERE company_id=1 AND stock_item_id=759 AND location_id=112;

-- loc 124: 8 BL @ 332.77
INSERT INTO inventory (company_id, location_id, stock_item_id, quantity, average_rate, total_value, last_updated)
VALUES (1, 124, 760, 8.000, 332.77, 2662.19, NOW());
UPDATE inventory SET quantity=quantity-8.000, total_value=total_value-2662.19,
    average_rate=CASE WHEN quantity-8.000>0 THEN (total_value-2662.19)/(quantity-8.000) ELSE average_rate END,
    last_updated=NOW()
WHERE company_id=1 AND stock_item_id=759 AND location_id=124;

-- loc 135: 24 BL @ 347.41
INSERT INTO inventory (company_id, location_id, stock_item_id, quantity, average_rate, total_value, last_updated)
VALUES (1, 135, 760, 24.000, 347.41, 8337.84, NOW());
UPDATE inventory SET quantity=quantity-24.000, total_value=total_value-8337.84,
    average_rate=CASE WHEN quantity-24.000>0 THEN (total_value-8337.84)/(quantity-24.000) ELSE average_rate END,
    last_updated=NOW()
WHERE company_id=1 AND stock_item_id=759 AND location_id=135;

-- loc 139: 10 BL @ 346.91
INSERT INTO inventory (company_id, location_id, stock_item_id, quantity, average_rate, total_value, last_updated)
VALUES (1, 139, 760, 10.000, 346.91, 3469.12, NOW());
UPDATE inventory SET quantity=quantity-10.000, total_value=total_value-3469.12,
    average_rate=CASE WHEN quantity-10.000>0 THEN (total_value-3469.12)/(quantity-10.000) ELSE average_rate END,
    last_updated=NOW()
WHERE company_id=1 AND stock_item_id=759 AND location_id=139;


-- ── AFTER: review these results before committing ──────────────

-- Item status (MJS16003 should show active=true, no deleted_at, no [MERGED])
SELECT id, code, name, active, deleted_at
FROM stock_items WHERE id IN (759, 760) AND company_id = 1;

-- Aliases (should be empty — the MJS16003→MJS6171 alias is gone)
SELECT * FROM stock_item_code_aliases
WHERE alias_code = 'MJS16003' OR stock_item_id IN (759, 760);

-- Inventory totals (MJS16003 should show 17 locations, ~77 BL, ~$26k)
SELECT si.code,
       COUNT(*)                          AS locations,
       SUM(i.quantity)                   AS total_qty,
       ROUND(SUM(i.total_value)::numeric,2) AS total_value
FROM inventory i
JOIN stock_items si ON si.id = i.stock_item_id
WHERE i.stock_item_id IN (759, 760) AND i.company_id = 1
GROUP BY si.code;

-- Inventory detail by location
SELECT si.code, i.location_id, i.quantity, i.average_rate, i.total_value
FROM inventory i
JOIN stock_items si ON si.id = i.stock_item_id
WHERE i.stock_item_id IN (759, 760) AND i.company_id = 1
ORDER BY si.code, i.location_id;

-- ================================================================
-- Sales and OTW are ALREADY CORRECT — no changes needed.
-- (Checked against backup: merge never touched those tables.)
--
-- When results look right:  COMMIT;
-- If anything is wrong:     ROLLBACK;
-- ================================================================
