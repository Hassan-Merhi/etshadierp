-- ================================================================
-- FIX SQL: Restore MJS16003 inventory after merge into MJS6171
-- Source: Render backup 2026-05-26T07:57Z (captured pre-merge state)
-- MJS16003 (MJS LADY SUMMER DRESS LONG CRÈME 40 KGS)   = stock_item_id 760
-- MJS6171  (MJS LADY SUMMER DRESS LONG + CREME 40 KGS) = stock_item_id 759
--
-- What this does:
--   CASE 1 (9 locations): MJS16003 was the only item with stock. The merge
--     remapped those inventory rows to MJS6171. We remap them back.
--   CASE 2 (8 locations): Both items had stock. The merge combined them into
--     MJS6171 and deleted MJS16003's rows. We INSERT them back and subtract
--     from MJS6171.
--
-- Sales, purchases, OTW containers are NOT affected — they were never
-- changed by the merge and already reference MJS16003 correctly.
--
-- HOW TO RUN ON RENDER:
--   1. Render dashboard → your PostgreSQL service → Connect (External URL)
--   2. psql "postgres://..." (paste connection string)
--   3. Paste this entire file, or: \i fix_mjs16003_inventory.sql
--   4. After the SELECT output looks correct → type COMMIT;
--      If anything looks wrong → type ROLLBACK;
-- ================================================================

BEGIN;

-- ── Verify both items exist ──────────────────────────────────────────────────
SELECT id, code, name, active
FROM stock_items
WHERE code IN ('MJS16003','MJS6171') AND company_id = 1;

-- ── Check MJS16003 current inventory (should be 0 or empty) ─────────────────
SELECT location_id, quantity, average_rate, total_value
FROM inventory
WHERE stock_item_id = 760 AND company_id = 1
ORDER BY location_id;

-- ── Check MJS6171 current inventory (will have the combined quantities) ──────
SELECT location_id, quantity, average_rate, total_value
FROM inventory
WHERE stock_item_id = 759 AND company_id = 1
ORDER BY location_id;


-- ================================================================
-- CASE 1: 9 locations — ONLY MJS16003 had stock here
-- The merge remapped these rows from stock_item_id=760 → 759.
-- Remapping them back is safe and exact — quantities are unchanged.
-- Locations: 21, 42, 46, 47, 50, 60, 69, 87, 127
-- Total: 18 BL
-- ================================================================
UPDATE inventory
SET stock_item_id = 760,
    last_updated  = NOW()
WHERE company_id   = 1
  AND stock_item_id = 759
  AND location_id IN (21, 42, 46, 47, 50, 60, 69, 87, 127);


-- ================================================================
-- CASE 2: 8 locations — BOTH items had stock
-- The merge deleted MJS16003's rows and added to MJS6171's rows.
-- Fix: INSERT MJS16003 rows back, then subtract from MJS6171.
-- Total: 59 BL / $20,791.29 value
-- ================================================================

-- loc 5 — MJS16003: 2 BL @ 332.25
INSERT INTO inventory (company_id, location_id, stock_item_id, quantity, average_rate, total_value, last_updated)
VALUES (1, 5, 760, 2.000, 332.25, 664.49, NOW());
UPDATE inventory SET
    quantity     = quantity     - 2.000,
    total_value  = total_value  - 664.49,
    average_rate = CASE WHEN (quantity - 2.000) > 0 THEN (total_value - 664.49) / (quantity - 2.000) ELSE average_rate END,
    last_updated = NOW()
WHERE company_id = 1 AND stock_item_id = 759 AND location_id = 5;

-- loc 76 — MJS16003: 2 BL @ 328.72
INSERT INTO inventory (company_id, location_id, stock_item_id, quantity, average_rate, total_value, last_updated)
VALUES (1, 76, 760, 2.000, 328.72, 657.43, NOW());
UPDATE inventory SET
    quantity     = quantity     - 2.000,
    total_value  = total_value  - 657.43,
    average_rate = CASE WHEN (quantity - 2.000) > 0 THEN (total_value - 657.43) / (quantity - 2.000) ELSE average_rate END,
    last_updated = NOW()
WHERE company_id = 1 AND stock_item_id = 759 AND location_id = 76;

-- loc 85 — MJS16003: 2 BL @ 331.96
INSERT INTO inventory (company_id, location_id, stock_item_id, quantity, average_rate, total_value, last_updated)
VALUES (1, 85, 760, 2.000, 331.96, 663.92, NOW());
UPDATE inventory SET
    quantity     = quantity     - 2.000,
    total_value  = total_value  - 663.92,
    average_rate = CASE WHEN (quantity - 2.000) > 0 THEN (total_value - 663.92) / (quantity - 2.000) ELSE average_rate END,
    last_updated = NOW()
WHERE company_id = 1 AND stock_item_id = 759 AND location_id = 85;

-- loc 100 — MJS16003: 3 BL @ 332.10
INSERT INTO inventory (company_id, location_id, stock_item_id, quantity, average_rate, total_value, last_updated)
VALUES (1, 100, 760, 3.000, 332.10, 996.30, NOW());
UPDATE inventory SET
    quantity     = quantity     - 3.000,
    total_value  = total_value  - 996.30,
    average_rate = CASE WHEN (quantity - 3.000) > 0 THEN (total_value - 996.30) / (quantity - 3.000) ELSE average_rate END,
    last_updated = NOW()
WHERE company_id = 1 AND stock_item_id = 759 AND location_id = 100;

-- loc 112 — MJS16003: 8 BL @ 332.85
INSERT INTO inventory (company_id, location_id, stock_item_id, quantity, average_rate, total_value, last_updated)
VALUES (1, 112, 760, 8.000, 332.85, 2662.83, NOW());
UPDATE inventory SET
    quantity     = quantity     - 8.000,
    total_value  = total_value  - 2662.83,
    average_rate = CASE WHEN (quantity - 8.000) > 0 THEN (total_value - 2662.83) / (quantity - 8.000) ELSE average_rate END,
    last_updated = NOW()
WHERE company_id = 1 AND stock_item_id = 759 AND location_id = 112;

-- loc 124 — MJS16003: 8 BL @ 332.77
INSERT INTO inventory (company_id, location_id, stock_item_id, quantity, average_rate, total_value, last_updated)
VALUES (1, 124, 760, 8.000, 332.77, 2662.19, NOW());
UPDATE inventory SET
    quantity     = quantity     - 8.000,
    total_value  = total_value  - 2662.19,
    average_rate = CASE WHEN (quantity - 8.000) > 0 THEN (total_value - 2662.19) / (quantity - 8.000) ELSE average_rate END,
    last_updated = NOW()
WHERE company_id = 1 AND stock_item_id = 759 AND location_id = 124;

-- loc 135 — MJS16003: 24 BL @ 347.41
INSERT INTO inventory (company_id, location_id, stock_item_id, quantity, average_rate, total_value, last_updated)
VALUES (1, 135, 760, 24.000, 347.41, 8337.84, NOW());
UPDATE inventory SET
    quantity     = quantity     - 24.000,
    total_value  = total_value  - 8337.84,
    average_rate = CASE WHEN (quantity - 24.000) > 0 THEN (total_value - 8337.84) / (quantity - 24.000) ELSE average_rate END,
    last_updated = NOW()
WHERE company_id = 1 AND stock_item_id = 759 AND location_id = 135;

-- loc 139 — MJS16003: 10 BL @ 346.91
INSERT INTO inventory (company_id, location_id, stock_item_id, quantity, average_rate, total_value, last_updated)
VALUES (1, 139, 760, 10.000, 346.91, 3469.12, NOW());
UPDATE inventory SET
    quantity     = quantity     - 10.000,
    total_value  = total_value  - 3469.12,
    average_rate = CASE WHEN (quantity - 10.000) > 0 THEN (total_value - 3469.12) / (quantity - 10.000) ELSE average_rate END,
    last_updated = NOW()
WHERE company_id = 1 AND stock_item_id = 759 AND location_id = 139;


-- ================================================================
-- VERIFY — Review both items after changes. Check numbers look right.
-- MJS16003 should have 17 locations with ~77 BL total.
-- MJS6171 should have reduced quantities at the 8 Case-2 locations.
-- ================================================================
SELECT si.code, i.location_id, i.quantity, i.average_rate, i.total_value
FROM inventory i
JOIN stock_items si ON si.id = i.stock_item_id
WHERE i.stock_item_id IN (759, 760) AND i.company_id = 1
ORDER BY si.code, i.location_id;

-- Totals check
SELECT si.code, COUNT(*) as locations, SUM(i.quantity) as total_qty, SUM(i.total_value) as total_value
FROM inventory i
JOIN stock_items si ON si.id = i.stock_item_id
WHERE i.stock_item_id IN (759, 760) AND i.company_id = 1
GROUP BY si.code;

-- ================================================================
-- If everything looks correct:  COMMIT;
-- If anything looks wrong:      ROLLBACK;
-- ================================================================

